﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectForYP.ClassHelper
{
    class ClassHelperUser
    {
        public static int UserId { get; set; }
    }
}
